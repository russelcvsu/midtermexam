<html>
<?php include('coderandomizer.php'); ?>
<head><title>CODE</title></head>

<h1>CODE: <input type="text" value="<?php echo  $pin2; ?>" readonly></h1>
</html>