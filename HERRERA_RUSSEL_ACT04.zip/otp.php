<html>
<?php include('otprandomizer.php'); ?>
<head><title>OTP</title></head>

<h1>OTP: <input type="text" value= '<?php echo  $pin;?>'  readonly></h1>
</html>